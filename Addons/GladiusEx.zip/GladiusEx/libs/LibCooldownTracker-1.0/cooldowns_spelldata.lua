-- Note: this global is removed after the library is loaded
LCT_SpellData = {}
