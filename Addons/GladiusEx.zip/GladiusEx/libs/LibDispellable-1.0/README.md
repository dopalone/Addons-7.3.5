LibDispellable-1.0 aims at helping to test if the player can really dispel an enemy buff or a friend debuff.

The current Blizzard implementation for a curable buff filter ("HARMFUL RAID") does not take talents into account. There is no way to test for buffs that players can dispel on their enemies. LibDispellable-1.0 provides methods to test both defensive and offensive dispels.

See the [API page on wowace.com](http://www.wowace.com/addons/libdispellable-1-0/pages/api/) for usage.
