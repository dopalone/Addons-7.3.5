# GladiusEX
An arena unit frames addon for Legion

# Author
Original author: slaren
Port to Legion: vendethiel.


-----

Repository: https://github.com/slaren/GladiusEx