# SexyMap

## [v7.3.3](https://github.com/funkydude/SexyMap/tree/v7.3.3) (2018-05-22)
[Full Changelog](https://github.com/funkydude/SexyMap/compare/v7.3.2...v7.3.3)

- Coordinates: You can now configure how fast the display updates (default 1). The lower the value the more memory/CPU will be used but the faster the display will refresh. This is important as asking the game for coordinate data is a lot more expensive in BfA.  
