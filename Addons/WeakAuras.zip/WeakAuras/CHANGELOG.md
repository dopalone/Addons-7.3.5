# [2.16.3](https://github.com/WeakAuras/WeakAuras2/tree/2.16.3) (2020-02-05)

[Full Changelog](https://github.com/WeakAuras/WeakAuras2/compare/2.16.2...2.16.3)

## Highlights

 Force enable Archive add-on because some add-on managers like to disable it by default 

## Commits

Stanzilla (1):

- force enable WeakAurasArchive

