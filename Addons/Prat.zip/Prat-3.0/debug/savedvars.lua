Prat.EnableTasks[#Prat.EnableTasks + 1] = function() Prat_Debug = Prat_Debug or {} end

