# BattleGroundEnemies
A enemy display for battlegrounds


An Addon to show you all enemies in a battleground. https://mods.curse.com/addons/wow/274066-battlegroundenemies
