local L = LibStub('AceLocale-3.0'):NewLocale('BattleGroundEnemies', 'esMX')

if not L then return end


