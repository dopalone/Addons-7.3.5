local L = LibStub('AceLocale-3.0'):NewLocale('BattleGroundEnemies', 'ptBR')

if not L then return end


