local L = LibStub('AceLocale-3.0'):NewLocale('BattleGroundEnemies', 'frFR')

if not L then return end

L["Allies"] = "Des Alliés"
L["allies"] = "des alliés"
L["ally"] = "Allié"
L["BOTTOM"] = "En bas"
L["BOTTOMLEFT"] = "En Bas à Gauche"
L["BOTTOMRIGHT"] = "En Bas à Droite"
L["Button"] = "Bouton"
L["CENTER"] = "Centre"
L["Columns"] = "Colonnes"
L["Disease"] = "Maladie"
L["Height"] = "La Taille"
L["LEFT"] = "La Gauche"
L["Locked"] = "Fermé à Clef"
L["Magic"] = "La Magie"
L["Name"] = "Prénom"
L["Point"] = "Point"
L["Poison"] = "Poison"
L["Position"] = "Position"
L["Side"] = "Le Côté"
L["TOP"] = "En Haut"
L["TOPLEFT"] = "En Haut à Gauche"
L["TOPRIGHT"] = "En Haut à Droite"

