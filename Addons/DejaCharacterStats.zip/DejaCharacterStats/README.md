A GitHub copy of WoW addon DejaCharacterStats for easier sharing/changing of code.
