# AstralKeys
Astral Keys is a Mythic+ keystone aggregator for World of Warcraft.
The main features are:
* Automatic syncing of guild member's keys
* Automatic announcement of player's key to party chat when acquiring a new key
* Announcement of player's keys on all its characters to Party or Guild
* Tracks Artifact Knowledge on all of player's characters to display expected Artifact Power gains from running each Mythic+ dungeon based on key level
* Tracks if each guild member has completed a weekly mythic level 10 or higher for maximum class hall item level cache reward.
