local AL = _G.AtlasLoot.GetLocales("itIT")

if not AL then return end

-- These localization strings are translated on WoWAce: https://www.wowace.com/projects/atlasloot-enhanced/localization
-- Options
AL["AtlasLoot Options"] = "Opzioni AtlasLoot"

