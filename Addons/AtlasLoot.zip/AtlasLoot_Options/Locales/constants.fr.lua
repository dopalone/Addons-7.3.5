local AL = _G.AtlasLoot.GetLocales("frFR")

if not AL then return end

-- These localization strings are translated on WoWAce: https://www.wowace.com/projects/atlasloot-enhanced/localization
-- Options
AL["AtlasLoot Options"] = [=[Options d'AtlasLoot
Options]=]

