local _G = getfenv(0)
local AtlasLoot = _G.AtlasLoot
local Addons = {}
AtlasLoot.Addons = Addons
