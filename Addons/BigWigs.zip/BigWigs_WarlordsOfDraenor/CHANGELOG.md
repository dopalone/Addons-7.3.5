# BigWigs [Warlords of Draenor]

## [v7.3.1](https://github.com/BigWigsMods/BigWigs_WarlordsOfDraenor/tree/v7.3.1) (2018-03-15)
[Full Changelog](https://github.com/BigWigsMods/BigWigs_WarlordsOfDraenor/compare/v7.3.0...v7.3.1)

- Fill in options data for repo users.  
- HellfireCitadel/KilroggDeadeye: Add SetOption comment  
- Add color & sound files  
- Update travis file  
- Swap to using LoadOn-InstanceId  
- Use instance ids in :NewBoss.  
- Cleanups  
- Update travis file  
- Update journal ID usage.  
