local L = BigWigs:NewBossLocale("Supreme Lord Kazzak", "zhTW")
if L then
L.engage_yell = "面對燃燒軍團的力量吧！"

end