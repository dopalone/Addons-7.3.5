local L = BigWigs:NewBossLocale("Supreme Lord Kazzak", "ruRU")
if L then
	L.engage_yell = "Вы познаете мощь Легиона!"
end