local L = BigWigs:NewBossLocale("Supreme Lord Kazzak", "frFR")
if L then
L.engage_yell = "Affrontez la puissance de la Légion ardente !"

end