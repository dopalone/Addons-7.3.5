local L = BigWigs:NewBossLocale("Supreme Lord Kazzak", "deDE")
if L then
L.engage_yell = "Ihr fordert die Macht der Brennenden Legion heraus!"

end