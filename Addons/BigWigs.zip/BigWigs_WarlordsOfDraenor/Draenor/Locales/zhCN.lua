local L = BigWigs:NewBossLocale("Supreme Lord Kazzak", "zhCN")
if L then
L.engage_yell = "你将面对燃烧军团的力量！"

end