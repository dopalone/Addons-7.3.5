local L = BigWigs:NewBossLocale("Supreme Lord Kazzak", "esES") or BigWigs:NewBossLocale("Supreme Lord Kazzak", "esMX")
if L then
-- L.engage_yell = "You face the might of the Burning Legion!"

end