local L = BigWigs:NewBossLocale("Supreme Lord Kazzak", "ptBR")
if L then
	L.engage_yell = "Você enfrenta o poder da Legião Ardente!"
end