local L = BigWigs:NewBossLocale("Supreme Lord Kazzak", "koKR")
if L then
L.engage_yell = "불타는 군단의 압도적인 힘을 느껴라!"

end