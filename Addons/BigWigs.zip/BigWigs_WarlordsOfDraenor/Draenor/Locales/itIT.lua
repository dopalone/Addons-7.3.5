local L = BigWigs:NewBossLocale("Supreme Lord Kazzak", "itIT")
if L then
-- L.engage_yell = "You face the might of the Burning Legion!"

end