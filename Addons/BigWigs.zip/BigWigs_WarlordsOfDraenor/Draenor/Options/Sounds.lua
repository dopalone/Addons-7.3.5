
BigWigs:AddSounds("Drov the Ruiner", {
	[175791] = "Alarm",
	[175915] = "Alarm",
})

BigWigs:AddSounds("Tarlna the Ageless", {
	[176037] = "Alert",
	[176001] = "Alert",
	[175979] = "Long",
	[175973] = "Alarm",
})

BigWigs:AddSounds("Rukhmar", {
	[167647] = "Long",
	[167757] = "Alarm",
	[167615] = "Warning",
})

BigWigs:AddSounds("Supreme Lord Kazzak", {
	[187471] = "Info",
	[187668] = "Alarm",
	[187664] = "Alert",
	[187702] = "Long",
})
