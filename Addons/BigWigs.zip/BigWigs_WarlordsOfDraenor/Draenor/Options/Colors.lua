
BigWigs:AddColors("Drov the Ruiner", {
	[175915] = "Personal",
	[175827] = "Attention",
	[175791] = "Important",
})

BigWigs:AddColors("Tarlna the Ageless", {
	[176013] = "Urgent",
	[175979] = "Attention",
	[175973] = "Important",
	[176037] = "Personal",
	[176001] = "Personal",
})

BigWigs:AddColors("Rukhmar", {
	[167647] = "Attention",
	[167757] = "Personal",
	[167615] = {"Attention","Personal"},
	[167679] = "Urgent",
})

BigWigs:AddColors("Supreme Lord Kazzak", {
	[187471] = {"Attention","Personal"},
	[187668] = "Personal",
	[187664] = {"Urgent","Personal"},
	[187702] = "Important",
})
