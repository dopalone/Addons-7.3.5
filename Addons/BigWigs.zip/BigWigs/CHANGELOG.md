# BigWigs

## [v98.1](https://github.com/BigWigsMods/BigWigs/tree/v98.1) (2018-07-10)
[Full Changelog](https://github.com/BigWigsMods/BigWigs/compare/v98...v98.1)

- Update some UnitDebuff calls to use ids.  
- TrialOfValor/Locales/itIT: Update Helya emotes.  
- Tweaks  
- Uldir/Mythrax: Minor changes, fix for Essence Shear sound spam for non-tanks  
- Uldir/Ghuun: Updates and fixes for Beta testing  
- Antorus/Kingaroth: Fix "Forging Strike" warnings/timers not working in LFR  
- Nighthold/Skorpyron: Fix self call in local function  
- Antorus/Aggramar: Move 2nd Intermission soon warning for Mythic to 37%  
