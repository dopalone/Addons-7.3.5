
BigWigs:AddColors("Imperial Vizier Zor'lok", {
	[122740] = {"Attention","Personal"},
	[122761] = {"Important","Personal"},
	["attenuation"] = {"Attention","Urgent"},
	["force"] = {"Important","Urgent"},
	["stages"] = "Positive",
})

BigWigs:AddColors("Blade Lord Ta'yak", {
	[-6350] = "Positive",
	[-6346] = {"Attention","Personal","Urgent"},
	[123474] = {"Personal","Urgent"},
	[125310] = "Important",
})

BigWigs:AddColors("Garalon", {
	[-6294] = "Positive",
	[122754] = "Urgent",
	[122774] = "Important",
	[122835] = {"Attention","Important","Personal"},
	[123081] = {"Attention","Personal"},
	[123120] = "Personal",
	[123495] = "Urgent",
})

BigWigs:AddColors("Wind Lord Mel'jarak", {
	[-6554] = "Attention",
	[121881] = {"Important","Personal"},
	[121896] = {"Personal","Urgent"},
	[122055] = "Positive",
	[122064] = "Personal",
	[122125] = "Personal",
	[122149] = "Attention",
	[122224] = "Personal",
	[122406] = "Important",
	[122409] = {"Personal","Urgent"},
	[131830] = {"Personal","Urgent"},
	["mending"] = "Personal",
	["recklessness"] = "Attention",
	["stages"] = "Positive",
})

BigWigs:AddColors("Amber-Shaper Un'sok", {
	[-6548] = {"Important","Personal"},
	[121949] = {"Personal","Urgent"},
	[121995] = "Attention",
	[122408] = "Urgent",
	[122413] = {"Personal","Urgent"},
	[122784] = {"Personal","Urgent"},
	[123020] = "Personal",
	[123060] = "Personal",
	["explosion_by_other"] = "Attention",
	["explosion_casting_by_other"] = {"Important","Personal"},
	["explosion_casting_by_you"] = "Personal",
	["stages"] = {"Attention","Positive"},
	["willpower"] = "Personal",
})

BigWigs:AddColors("Grand Empress Shek'zeer", {
	[-6325] = "Attention",
	[123788] = {"Attention","Personal"},
	[123845] = {"Important","Personal"},
	[124077] = "Urgent",
	[124097] = "Personal",
	[124849] = "Important",
	[124862] = {"Attention","Important","Personal"},
	[125390] = {"Attention","Personal"},
	[125826] = "Attention",
	["eyes"] = {"Personal","Urgent"},
	["phases"] = "Positive",
})
