local L = BigWigs:NewBossLocale("Imperial Vizier Zor'lok", "ptBR")
if not L then return end
if L then

end

L = BigWigs:NewBossLocale("Blade Lord Ta'yak", "ptBR")
if L then

end

L = BigWigs:NewBossLocale("Garalon", "ptBR")
if L then

end

L = BigWigs:NewBossLocale("Wind Lord Mel'jarak", "ptBR")
if L then

end

L = BigWigs:NewBossLocale("Amber-Shaper Un'sok", "ptBR")
if L then

end

L = BigWigs:NewBossLocale("Grand Empress Shek'zeer", "ptBR")
if L then

end

