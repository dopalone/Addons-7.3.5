
local L = BigWigs:NewBossLocale("Protectors of the Endless", "ptBR")
if not L then return end
if L then

end

L = BigWigs:NewBossLocale("Tsulong", "ptBR")
if L then

end

L = BigWigs:NewBossLocale("Lei Shi", "ptBR")
if L then

end

L = BigWigs:NewBossLocale("Sha of Fear", "ptBR")
if L then

end

