
BigWigs:AddColors("Protectors of the Endless", {
	[117052] = "Attention",
	[117227] = "Attention",
	[117309] = {"Attention","Important","Urgent"},
	[117436] = {"Important","Personal"},
	[117975] = "Urgent",
	[117986] = "Personal",
	[118077] = "Urgent",
})

BigWigs:AddColors("Tsulong", {
	[-6550] = "Urgent",
	[122752] = "Urgent",
	[122768] = "Personal",
	[122777] = {"Attention","Important","Personal"},
	[122789] = "Positive",
	[122855] = "Urgent",
	[123011] = "Important",
	["embodied_terror"] = "Attention",
	["phases"] = {"Attention","Positive"},
	["unstable_sha"] = "Important",
})

BigWigs:AddColors("Lei Shi", {
	[123121] = {"Personal","Urgent"},
	[123244] = "Attention",
	[123250] = {"Important","Positive"},
	[123461] = {"Important","Positive"},
	[123705] = {"Attention","Personal"},
	["special"] = "Attention",
})

BigWigs:AddColors("Sha of Fear", {
	[-6700] = "Important",
	[-6699] = {"Important","Urgent"},
	[-6109] = "Personal",
	[-6107] = "Positive",
	[118977] = "Attention",
	[119414] = "Attention",
	[119519] = "Urgent",
	[119888] = {"Attention","Important"},
	[120268] = {"Personal","Positive"},
	[120455] = "Attention",
	[120519] = {"Personal","Urgent"},
	[120629] = {"Important","Personal"},
	[120669] = {"Important","Personal","Urgent"},
	[120672] = "Attention",
	[129147] = {"Personal","Urgent"},
	[129378] = "Positive",
	["berserk"] = "Attention",
	["swing"] = "Positive",
})
