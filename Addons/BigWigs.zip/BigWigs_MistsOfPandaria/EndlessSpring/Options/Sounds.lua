
BigWigs:AddSounds("Protectors of the Endless", {
	[117052] = "Info",
	[117309] = {"Alert","Info"},
	[117436] = "Alert",
	[117986] = "Info",
	[118077] = "Alarm",
})

BigWigs:AddSounds("Tsulong", {
	[-6550] = "Alarm",
	[122768] = "Info",
	[122777] = "Alert",
	[123011] = "Alert",
	["phases"] = "Alert",
	["unstable_sha"] = "Alert",
})

BigWigs:AddSounds("Lei Shi", {
	[123121] = "Info",
	[123250] = "Alarm",
	[123461] = "Alarm",
})

BigWigs:AddSounds("Sha of Fear", {
	[-6700] = "Alarm",
	[-6109] = "Long",
	[119414] = "Long",
	[119519] = "Alarm",
	[119888] = "Alert",
	[120268] = "Long",
	[120519] = "Info",
	[120629] = "Alert",
	[120669] = "Info",
	[120672] = "Alarm",
	[129378] = "Long",
})
