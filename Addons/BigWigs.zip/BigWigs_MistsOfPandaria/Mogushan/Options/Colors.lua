
BigWigs:AddColors("The Stone Guard", {
	[116529] = "Urgent",
	[130395] = {"Attention","Personal"},
	[130774] = "Personal",
	["overload"] = "Important",
})

BigWigs:AddColors("Feng the Accursed", {
	[115817] = "Urgent",
	[115911] = {"Personal","Urgent"},
	[116018] = "Important",
	[116157] = "Urgent",
	[116364] = {"Attention","Important"},
	[116417] = {"Personal","Urgent"},
	[116711] = "Important",
	[116784] = {"Personal","Urgent"},
	[118071] = "Important",
	["stages"] = "Positive",
	["tank"] = {"Personal","Urgent"},
})

BigWigs:AddColors("Gara'jal the Spiritbinder", {
	[-5759] = "Positive",
	[116174] = "Attention",
	[116272] = "Urgent",
	[122151] = {"Important","Personal"},
})

BigWigs:AddColors("The Spirit Kings", {
	[117697] = {"Important","Positive"},
	[117708] = "Urgent",
	[117837] = "Urgent",
	[117910] = "Attention",
	[117961] = {"Important","Positive"},
	[118047] = "Urgent",
	[118094] = "Urgent",
	[118122] = {"Important","Personal"},
	[118162] = "Important",
	[118303] = "Personal",
	[119521] = "Urgent",
	["bosses"] = "Positive",
	["cowardice"] = {"Attention","Personal","Positive","Urgent"},
})

BigWigs:AddColors("Elegon", {
	[-6186] = "Important",
	[117878] = "Personal",
	[119360] = "Attention",
	["adds"] = "Attention",
	["floor"] = "Personal",
	["stages"] = "Positive",
})

BigWigs:AddColors("Will of the Emperor", {
	[-5670] = {"Attention","Important"},
	[116525] = "Personal",
	[116829] = {"Attention","Personal"},
	["arc"] = "Urgent",
	["bosses"] = "Attention",
	["combo"] = "Personal",
	["courage"] = "Attention",
	["rage"] = "Attention",
	["strength"] = "Attention",
})
