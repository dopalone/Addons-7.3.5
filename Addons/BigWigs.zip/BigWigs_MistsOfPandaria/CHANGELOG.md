# BigWigs [Mists of Pandaria]

## [v7.3.4](https://github.com/BigWigsMods/BigWigs_MistsOfPandaria/tree/v7.3.4) (2018-04-01)
[Full Changelog](https://github.com/BigWigsMods/BigWigs_MistsOfPandaria/compare/v7.3.3...v7.3.4)

- SiegeOfOrgrimmar/TheFallenProtectors: Use a custom fallback for the target scan.  
