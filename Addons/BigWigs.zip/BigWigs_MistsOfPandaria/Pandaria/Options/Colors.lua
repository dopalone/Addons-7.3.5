
BigWigs:AddColors("Sha of Anger", {
	[119488] = "Important",
	[119610] = "Personal",
	[119622] = "Personal",
	[119626] = {"Attention","Personal","Urgent"},
})

BigWigs:AddColors("Salyis's Warband", {
	[-6200] = "Attention",
	[121600] = "Urgent",
	[121787] = "Important",
})

BigWigs:AddColors("Nalak", {
	[136338] = "Important",
	[136339] = "Personal",
	[136340] = {"Attention","Personal"},
})

BigWigs:AddColors("Oondasta", {
	[137457] = "Attention",
	[137504] = {"Personal","Urgent"},
	[137505] = "Important",
})

BigWigs:AddColors("Ordos", {
	[144688] = "Urgent",
	[144689] = {"Personal","Urgent"},
	[144692] = {"Attention","Personal"},
	[144695] = {"Attention","Personal"},
})
