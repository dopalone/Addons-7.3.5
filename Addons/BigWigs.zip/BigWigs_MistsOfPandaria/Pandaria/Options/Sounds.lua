
BigWigs:AddSounds("Sha of Anger", {
	[119610] = "Info",
	[119622] = "Alert",
	[119626] = "Alarm",
})

BigWigs:AddSounds("Salyis's Warband", {
	[121787] = "Alarm",
})

BigWigs:AddSounds("Nalak", {
	[136338] = "Alarm",
	[136339] = "Alert",
	[136340] = {"Alert","Info"},
})

BigWigs:AddSounds("Oondasta", {
	[137457] = "Long",
	[137504] = "Info",
	[137505] = "Alert",
})

BigWigs:AddSounds("Ordos", {
	[144689] = "Alert",
	[144692] = {"Alarm","Info"},
	[144695] = "Info",
})
