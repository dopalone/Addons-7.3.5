local L = BigWigs:NewBossLocale("Withered J'im", "ptBR")
if not L then return end
if L then
	L.custom_on_mark_boss = "Marca J'im Fenecido"
	L.custom_on_mark_boss_desc = "Marca o verdadeiro J'im Fenecido com {rt8}, requer assistente ou líder."
end
