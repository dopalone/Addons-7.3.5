local L = BigWigs:NewBossLocale("Withered J'im", "ruRU")
if not L then return end
if L then
	L.custom_on_mark_boss = "Отмечать Иссохшего Джима"
	L.custom_on_mark_boss_desc = "Отмечать настоящего Иссохшего Джима меткой {rt8}, требуется быть помощником или лидером рейда."
end
