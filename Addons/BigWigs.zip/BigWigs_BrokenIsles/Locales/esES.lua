local L = BigWigs:NewBossLocale("Withered J'im", "esES") or BigWigs:NewBossLocale("Withered J'im", "esMX")
if not L then return end
if L then
	--L.custom_on_mark_boss = "Mark Withered J'im"
	--L.custom_on_mark_boss_desc = "Mark the real Withered J'im with {rt8}, requires promoted or leader."
end
