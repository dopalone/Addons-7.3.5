local L = BigWigs:NewBossLocale("Withered J'im", "zhCN")
if not L then return end
if L then
	L.custom_on_mark_boss = "标记凋零者吉姆"
	L.custom_on_mark_boss_desc = "使用 {rt8} 标记凋零者吉姆真身，需要权限。"
end
