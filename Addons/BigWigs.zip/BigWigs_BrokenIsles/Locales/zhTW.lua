local L = BigWigs:NewBossLocale("Withered J'im", "zhTW")
if not L then return end
if L then
	L.custom_on_mark_boss = "標記凋萎者吉姆"
	L.custom_on_mark_boss_desc = "用{rt8}標記真正的凋萎者吉姆，需要權限。"
end
