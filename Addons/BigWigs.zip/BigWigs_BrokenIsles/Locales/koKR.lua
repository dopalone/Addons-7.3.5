local L = BigWigs:NewBossLocale("Withered J'im", "koKR")
if not L then return end
if L then
	L.custom_on_mark_boss = "메마른 짐 징표 표시"
	L.custom_on_mark_boss_desc = "진짜 메마른 짐에 {rt8}로 징표 표시합니다, 부공격대장 이상의 권한이 필요합니다."
end
