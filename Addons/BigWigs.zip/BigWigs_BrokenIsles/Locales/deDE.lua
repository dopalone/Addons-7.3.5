local L = BigWigs:NewBossLocale("Withered J'im", "deDE")
if not L then return end
if L then
	L.custom_on_mark_boss = "Verdorrter J'im markieren"
	L.custom_on_mark_boss_desc = "Markiert den echten Verdorrten J'im mit {rt8}, benötigt Leiter oder Assistent."
end
