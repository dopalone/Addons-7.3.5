local L = BigWigs:NewBossLocale("Withered J'im", "frFR")
if not L then return end
if L then
	L.custom_on_mark_boss = "Marquage J'im le Flétri"
	L.custom_on_mark_boss_desc = "Marque le véritable J'im le Flétri avec {rt8}. Nécessite d'être assistant ou chef de raid."
end
