
BigWigs:AddColors("Matron Folnuna", {
	[247361] = {"Neutral","Personal"},
	[247379] = {"Personal","Urgent"},
	[247443] = "Important",
	[254147] = "Attention",
})

BigWigs:AddColors("Mistress Alluradel", {
	[247517] = "Personal",
	[247544] = {"Personal","Urgent"},
	[247549] = "Urgent",
	[247604] = "Attention",
})

BigWigs:AddColors("Inquisitor Meto", {
	[247492] = {"Attention","Personal"},
	[247495] = {"Attention","Personal"},
	[247585] = {"Positive","Urgent"},
	[247632] = "Personal",
})

BigWigs:AddColors("Sothanar", {
	[247410] = {"Important","Neutral","Personal"},
	[247416] = "Attention",
	[247437] = {"Personal","Urgent"},
	[247698] = "Attention",
})

BigWigs:AddColors("Occularus", {
	[247318] = {"Important","Personal"},
	[247320] = "Urgent",
	[247325] = "Attention",
	[247332] = {"Attention","Personal"},
	[247393] = {"Neutral","Personal"},
})

BigWigs:AddColors("Pit Lord Vilemus", {
	[247731] = "Important",
	[247733] = "Urgent",
	[247739] = {"Attention","Neutral","Personal"},
})
