﻿local L = LibStub("AceLocale-3.0"):NewLocale("TidyPlatesThreat", "zhCN", false)
if not L then return end

L["%.1f千"] = true
L["%.1f亿"] = true