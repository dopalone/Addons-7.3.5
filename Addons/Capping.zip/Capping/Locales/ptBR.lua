if GetLocale() ~= "ptBR" then return end

local _, addon = ...
addon.L = {

}

