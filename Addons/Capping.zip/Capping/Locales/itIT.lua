if GetLocale() ~= "itIT" then return end

local _, addon = ...
addon.L = {

}

