if GetLocale() ~= "esES" then return end

local _, addon = ...
addon.L = {

}

