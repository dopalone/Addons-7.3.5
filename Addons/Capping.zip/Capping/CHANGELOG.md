# Capping

## [v7.3.7](https://github.com/BigWigsMods/Capping/tree/v7.3.7) (2018-07-13)
[Full Changelog](https://github.com/BigWigsMods/Capping/compare/v7.3.6...v7.3.7)

- Comment out some broken things for now.  
- Fix some bar colors.  
