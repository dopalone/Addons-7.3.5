ZGV.Gold.guides_loaded=true

ZygorGuidesViewer.GuideMenuTier = "BFA"
