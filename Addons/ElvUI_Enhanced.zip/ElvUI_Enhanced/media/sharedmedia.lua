local LSM = LibStub("LibSharedMedia-3.0")

if LSM == nil then return end
