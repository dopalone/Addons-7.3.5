-- Mini Dragon(projecteurs@gmail.com)
-- 夏一可
-- Blizzard Entertainment
-- Last update: 2018/05/02

if GetLocale() ~= "zhCN" then return end
local L

-----------------------
-- T'zane --
-----------------------
L= DBM:GetModLocalization(2139)

-----------------------
-- Ji'arak --
-----------------------
L= DBM:GetModLocalization(2141)
