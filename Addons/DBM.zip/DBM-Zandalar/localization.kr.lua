if GetLocale() ~= "koKR" then return end
local L

-----------------------
-- T'zane --
-----------------------
L= DBM:GetModLocalization(2139)

-----------------------
-- Ji'arak --
-----------------------
L= DBM:GetModLocalization(2141)
