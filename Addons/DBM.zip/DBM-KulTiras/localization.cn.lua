-- Mini Dragon(projecteurs@gmail.com)
-- 夏一可
-- Blizzard Entertainment
-- Last update: 2018/05/02

if GetLocale() ~= "zhCN" then return end
local L

-----------------------
-- Hailstone Construct --
-----------------------
L= DBM:GetModLocalization(2197)

-----------------------
-- Azurethos, The Winged Typhoon --
-----------------------
L= DBM:GetModLocalization(2199)

-----------------------
-- Warbringer Yenajz --
-----------------------
L= DBM:GetModLocalization(2198)
