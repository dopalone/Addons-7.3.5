local L

-----------------------
-- Hailstone Construct --
-----------------------
L= DBM:GetModLocalization(2197)

-----------------------
-- Azurethos, The Winged Typhoon --
-----------------------
L= DBM:GetModLocalization(2199)

-----------------------
-- Warbringer Yenajz --
-----------------------
L= DBM:GetModLocalization(2198)
