-- Local stuff
--Russian localization file
--Translated by StingerSoft
if (GetLocale() == "ruRU") then
XPERL_RAID_MONITOR_TITLE		= "Монитор применений |c00A04040(БЕТА)|r"
XPERL_RAID_MONITOR_TOTALS		= "Переключатель отображения всего и статистика"

XPERL_RAID_MONITOR_STATS_RAID_MANA	= "Мана рейда"
XPERL_RAID_MONITOR_STATS_HIGH_MANA	= "Полная мана"
XPERL_RAID_MONITOR_STATS_LOW_MANA	= "Избыток маны"
XPERL_RAID_MONITOR_STATS_RAID_HEALTH	= "Здоровье рейда"

XPERL_MONITOR_LEFTCLICK			= "|c00FFFFFFЛевый клик|r для %s"
XPERL_MONITOR_RIGHTCLICK		= "|c00FFFFFFПравый клик|r для %s"
XPERL_MONITOR_CLICKCAST			= "прим. |c0000FF00%s|r"
XPERL_MONITOR_CLICKTARGET		= "|c00FFFF80цель|r"

XPERL_MONITOR_INNERVATE			= "Озарение"
XPERL_MONITOR_MANATIDE			= "Тотем прилива маны"

XPERL_LOC_OOR				= "n/a"
end

