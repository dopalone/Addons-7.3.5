# MethodDungeonTools

[![Foo](https://i.imgur.com/VqoOFgI.png)](https://www.patreon.com/methoddungeontools)

If you would like to support the development of the Method Dungeon Tools you can become a patron and reap special rewards!

World of Warcraft AddOn for planning and optimizing Mythic+ dungeon runs 

Make sure to rename the folder from MethodDungeonTools-Master to MethodDungeonTools if you wanna test the AddOn!
To track progress of what is implemented in the dungeons check out the spreadsheet here:
https://docs.google.com/spreadsheets/d/162UG2gTmxgIaX0Clvl26bZa8revpncMegcBLmyDa8Es/preview
