
BigWigs:AddSounds("General Husam", {
	[83113] = "Alert",
	[83445] = "Info",
	[91263] = "Alarm",
})

BigWigs:AddSounds("Lockmaw", {
	[81690] = "Alert",
})

BigWigs:AddSounds("High Prophet Barim", {
	[82622] = "Alarm",
})

BigWigs:AddSounds("Siamat", {
	["servant"] = "Alert",
	["stages"] = "Info",
})
