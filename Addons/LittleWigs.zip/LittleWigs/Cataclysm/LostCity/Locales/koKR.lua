local L = BigWigs:NewBossLocale("Siamat", "koKR")
if not L then return end
if L then
	L.servant = "하수인 소환"
	L.servant_desc = "시아마트의 하수인이 소환되면 경보합니다."
end
