local L = BigWigs:NewBossLocale("Siamat", "zhCN")
if not L then return end
if L then
	L.servant = "召唤仆从"
	L.servant_desc = "当召唤希亚玛特的仆从时发出警报。"
end
