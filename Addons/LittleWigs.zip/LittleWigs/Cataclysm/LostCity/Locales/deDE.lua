local L = BigWigs:NewBossLocale("Siamat", "deDE")
if not L then return end
if L then
	L.servant = "Diener von Siamat beschwören"
	L.servant_desc = "Warnt, wenn ein Diener von Siamat beschworen wird."
end
