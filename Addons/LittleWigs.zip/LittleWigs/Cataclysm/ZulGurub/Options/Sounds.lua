
BigWigs:AddSounds("High Priest Venoxis", {
	[96466] = "Alert",
	[96477] = "Alarm",
	[96653] = "Info",
	[96842] = "Alert",
})

BigWigs:AddSounds("Bloodlord Mandokir", {
	[96684] = "Alert",
	[96724] = "Info",
	[96740] = "Info",
	[96776] = "Alert",
	[96800] = "Long",
})

BigWigs:AddSounds("High Priestess Kilnara", {
	[-2702] = "Alert",
	[96423] = "Alert",
	[96435] = "Alert",
	[96592] = "Alert",
	["stages"] = "Info",
})

BigWigs:AddSounds("Zanzil", {
	[96316] = "Alert",
	[96338] = "Alert",
	[96914] = "Info",
})

BigWigs:AddSounds("Jin'do the Godbreaker", {
	[-2910] = "Alert",
	[97170] = "Long",
	[97172] = {"Info","Long"},
	["stages"] = "Long",
})
