
BigWigs:AddSounds("Temple Guardian Anhuur", {
	[74938] = "Long",
	[75592] = "Alert",
})

BigWigs:AddSounds("Anraphet", {
	[75622] = "Alarm",
	[76184] = "Alert",
})

BigWigs:AddSounds("Isiset", {
	[-2556] = "Info",
	[74045] = "Alert",
	[74135] = "Alert",
	[74137] = "Alarm",
})

BigWigs:AddSounds("Ammunae", {
	[75790] = "Info",
	[76043] = {"Alarm","Alert"},
	[80968] = "Long",
})

BigWigs:AddSounds("Rajh", {
	[-2863] = "Warning",
	[76355] = "Long",
})
