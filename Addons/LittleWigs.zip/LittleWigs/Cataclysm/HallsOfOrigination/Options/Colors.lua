
BigWigs:AddColors("Temple Guardian Anhuur", {
	[74938] = {"Attention","Important"},
	[75592] = {"Attention","Personal"},
})

BigWigs:AddColors("Anraphet", {
	[75603] = {"Personal","Urgent"},
	[75609] = "Personal",
	[75622] = "Important",
	[76184] = {"Attention","Personal"},
})

BigWigs:AddColors("Isiset", {
	[-2556] = {"Neutral","Positive"},
	[74045] = "Personal",
	[74135] = "Personal",
	[74137] = "Important",
	[74373] = "Attention",
})

BigWigs:AddColors("Ammunae", {
	[75790] = "Attention",
	[76043] = {"Important","Personal","Urgent"},
	[80968] = {"Attention","Personal"},
})

BigWigs:AddColors("Rajh", {
	[-2863] = "Personal",
	[-2862] = "Urgent",
	[-2861] = "Attention",
	[76355] = {"Neutral","Positive"},
})
