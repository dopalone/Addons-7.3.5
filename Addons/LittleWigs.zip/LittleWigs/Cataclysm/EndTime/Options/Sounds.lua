
BigWigs:AddSounds("Echo of Baine", {
	[-4141] = {"Alarm","Info"},
	[-4140] = "Alert",
})
