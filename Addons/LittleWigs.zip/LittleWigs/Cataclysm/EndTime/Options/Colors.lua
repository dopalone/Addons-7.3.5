
BigWigs:AddColors("Echo of Baine", {
	[-4141] = {"Important","Positive"},
	[-4140] = {"Important","Personal"},
})
