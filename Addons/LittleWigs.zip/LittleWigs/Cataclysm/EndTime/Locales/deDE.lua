local L = BigWigs:NewBossLocale("Echo of Baine", "deDE")
if not L then return end
if L then
	-- L.totemDrop = "Totem dropped"
	-- L.totemThrow = "Totem thrown by %s"
end
