local L = BigWigs:NewBossLocale("Ozumat", "koKR")
if not L then return end
if L then
	L.custom_on_autotalk = "자동 대화"
	L.custom_on_autotalk_desc = "전투를 시작하는 대화 선택지를 즉시 선택합니다."
end
