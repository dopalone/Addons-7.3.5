
BigWigs:AddColors("Lady Naz'jar", {
	[75683] = "Attention",
})

BigWigs:AddColors("Commander Ulthok", {
	[76026] = {"Personal","Urgent"},
	[76047] = "Important",
	[76094] = {"Attention","Personal"},
	[76100] = "Attention",
})

BigWigs:AddColors("Mindbender Ghur'sha", {
	[76207] = {"Important","Personal"},
	[76230] = "Personal",
	[76307] = "Urgent",
	["stages"] = "Positive",
})

BigWigs:AddColors("Ozumat", {
	["stages"] = {"Attention","Positive"},
})
