local L = BigWigs:NewBossLocale("Well Of Eternity Trash", "zhCN")
if not L then return end
if L then
	L.custom_on_autotalk = "自动对话"
	L.custom_on_autotalk_desc = "立即选择伊利丹对话选项。"
end
