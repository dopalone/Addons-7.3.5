local L = BigWigs:NewBossLocale("Well Of Eternity Trash", "itIT")
if not L then return end
if L then
	--L.custom_on_autotalk = "Autotalk"
	--L.custom_on_autotalk_desc = "Instantly select Illidan's gossip option."
end
