
BigWigs:AddSounds("Altairus", {
	[88282] = "Info",
	[88286] = "Info",
})
