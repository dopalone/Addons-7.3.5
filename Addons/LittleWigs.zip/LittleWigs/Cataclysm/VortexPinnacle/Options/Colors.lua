
BigWigs:AddColors("Grand Vizier Ertan", {
	[86340] = "Attention",
})

BigWigs:AddColors("Altairus", {
	[88282] = "Personal",
	[88286] = "Personal",
	[88308] = {"Personal","Urgent"},
})

BigWigs:AddColors("Asaad", {
	[86930] = "Important",
	[87618] = "Attention",
})
