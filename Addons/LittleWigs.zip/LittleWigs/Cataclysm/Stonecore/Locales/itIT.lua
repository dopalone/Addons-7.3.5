local L = BigWigs:NewBossLocale("Corborus", "itIT")
if not L then return end
if L then
	--L.burrow = "Burrow/emerge"
	--L.burrow_desc = "Warn when Corborus burrows or emerges."
	--L.burrow_message = "Corborus burrows!"
	--L.burrow_warning = "Burrow in 5 sec!"
	--L.emerge_message = "Corborus emerges!"
	--L.emerge_warning = "Emerge in 5 sec!"
end
