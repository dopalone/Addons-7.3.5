local L = BigWigs:NewBossLocale("Assault on Violet Hold Trash", "esES") or BigWigs:NewBossLocale("Assault on Violet Hold Trash", "esMX")
if not L then return end
if L then
	--L.custom_on_autotalk = "Autotalk"
	--L.custom_on_autotalk_desc = "Instantly selects Lieutenant Sinclaris gossip option to start the Assault on Violet Hold."
	--L.keeper = "Portal Keeper"
	--L.guardian = "Portal Guardian"
	--L.infernal = "Blazing Infernal"
end

L = BigWigs:NewBossLocale("Thalena", "esES") or BigWigs:NewBossLocale("Thalena", "esMX")
if L then
	--L.essence = "Essence"
end