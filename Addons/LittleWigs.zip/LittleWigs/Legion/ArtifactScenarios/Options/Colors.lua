
BigWigs:AddColors("Tugar Bloodtotem", {
	[241687] = "Important",
	[242733] = "Urgent",
	[243224] = {"Important","Personal"},
	["charge"] = "Personal",
	["rupture"] = "Attention",
	["submerge"] = "Urgent",
})

BigWigs:AddColors("Kruul", {
	[233473] = "Positive",
	[234422] = "Personal",
	[234423] = "Urgent",
	[234428] = "Attention",
	[234631] = "Important",
	[234673] = "Urgent",
	[234676] = "Urgent",
	[234920] = "Attention",
	[236572] = "Important",
	[240790] = "Important",
	["nether_aberration"] = "Attention",
	["smoldering_infernal"] = "Attention",
	["stages"] = "Positive",
})

BigWigs:AddColors("Raest", {
	[202081] = "Important",
	[235308] = "Positive",
	[235578] = {"Personal","Urgent"},
	["handFromBeyond"] = "Neutral",
	["rune"] = "Attention",
	["thing"] = "Important",
})

BigWigs:AddColors("Archmage Xylem", {
	[231443] = "Urgent",
	[231522] = "Important",
	[232672] = "Personal",
	[233248] = "Important",
	[234728] = "Neutral",
	[242015] = "Attention",
	["stages"] = "Neutral",
})

BigWigs:AddColors("Lord Erdris Thorn", {
	[235823] = "Urgent",
	[235833] = "Attention",
	[235984] = "Important",
	[236720] = "Important",
	[237188] = "Important",
	[237191] = "Urgent",
})

BigWigs:AddColors("Agatha", {
	[236161] = "Personal",
	[242989] = "Neutral",
	[243027] = {"Positive","Urgent"},
	[243111] = {"Important","Positive"},
	["fuming_imp"] = "Urgent",
	["imp_servant"] = "Attention",
	["stages"] = "Neutral",
})
