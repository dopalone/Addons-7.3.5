
BigWigs:AddColors("Amalgam of Souls", {
	[194956] = "Attention",
	[195254] = "Attention",
	[196587] = {"Attention","Important"},
})

BigWigs:AddColors("Illysanna Ravencrest", {
	[197797] = {"Attention","Personal"},
	[197974] = "Important",
})

BigWigs:AddColors("Smashspite", {
	[198073] = "Urgent",
	[198079] = {"Attention","Personal"},
	[198245] = "Positive",
	[198446] = "Important",
})

BigWigs:AddColors("Kurtalos Ravencrest", {
	[198641] = "Attention",
	[198820] = "Attention",
	[202019] = {"Attention","Important"},
})

BigWigs:AddColors("Black Rook Hold Trash", {
	[197974] = "Urgent",
	[200248] = "Attention",
	[200261] = "Urgent",
	[200291] = "Important",
	[200343] = "Attention",
	[203163] = {"Personal","Urgent"},
	[214003] = "Important",
	[225573] = "Attention",
	[227913] = "Attention",
})
