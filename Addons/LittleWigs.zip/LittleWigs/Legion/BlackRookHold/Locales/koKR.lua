local L = BigWigs:NewBossLocale("Black Rook Hold Trash", "koKR")
if not L then return end
if L then
	L.arcanist = "되살아난 비전술사"
	L.champion = "영혼 찢긴 용사"
	L.swordsman = "되살아난 검사"
	L.archer = "되살아난 궁수"
	L.scout = "되살아난 정찰병"
	L.councilor = "유령 의원"
	L.dominator = "지옥원한 통솔자"
end
