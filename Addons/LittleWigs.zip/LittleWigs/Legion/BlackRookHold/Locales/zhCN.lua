local L = BigWigs:NewBossLocale("Black Rook Hold Trash", "zhCN")
if not L then return end
if L then
	L.arcanist = "复活的奥术师"
	L.champion = "失魂的勇士"
	L.swordsman = "复活的剑士"
	L.archer = "复活的弓箭手"
	L.scout = "复活的斥候"
	L.councilor = "幽灵顾问"
	L.dominator = "魔怨支配者"
end
