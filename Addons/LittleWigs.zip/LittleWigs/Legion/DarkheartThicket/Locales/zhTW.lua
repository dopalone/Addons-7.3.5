local L = BigWigs:NewBossLocale("Darkheart Thicket Trash", "zhTW")
if not L then return end
if L then
	--L.ruiner = "Dreadsoul Ruiner"
	--L.poisoner = "Dreadsoul Poisoner"
	--L.razorbeak = "Crazed Razorbeak"
	--L.grizzly = "Festerhide Grizzly"
	--L.fury = "Bloodtainted Fury"
	--L.imp = "Dreadfire Imp"
end
