local L = BigWigs:NewBossLocale("Darkheart Thicket Trash", "zhCN")
if not L then return end
if L then
	L.ruiner = "恐魂毁灭者"
	L.poisoner = "恐魂施毒者"
	L.razorbeak = "发狂的锋喙狮鹫"
	L.grizzly = "烂皮灰熊"
	L.fury = "污血之怒"
	L.imp = "骇火小鬼"
end
