local L = BigWigs:NewBossLocale("Darkheart Thicket Trash", "ruRU")
if not L then return end
if L then
	L.ruiner = "Грозный разрушитель"
	L.poisoner = "Грозный отравитель"
	L.razorbeak = "Обезумевший остроклюв"
	L.grizzly = "Гноешкурый гризли"
	L.fury = "Оскверненная кровью ярость"
	L.imp = "Бес ужасающего огня"
end
