local L = BigWigs:NewBossLocale("Darkheart Thicket Trash", "ptBR")
if not L then return end
if L then
	L.ruiner = "Arruinador Almatorpe"
	L.poisoner = "Envenenador Almatorpe"
	L.razorbeak = "Bicofino Enlouquecido"
	L.grizzly = "Pelepodre Pardo"
	L.fury = "Fúria Manchada de Sangue"
	L.imp = "Diabrete do Fogo Mórbido"
end
