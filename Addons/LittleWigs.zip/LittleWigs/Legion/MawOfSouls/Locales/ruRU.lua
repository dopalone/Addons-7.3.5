local L = BigWigs:NewBossLocale("Maw of Souls Trash", "ruRU")
if not L then return end
if L then
	L.soulguard = "Промокший насквозь страж душ"
	L.champion = "Хеларьяр-защитник"
	L.mariner = "Моряк из Ночного дозора"
	L.swiftblade = "Проклятый морем молниеносный клинок"
	L.mistmender = "Проклятая морем целительница туманов"
	L.mistcaller = "Хеларьяр - призывательница туманов"
	L.skjal = "Скьял"
end
