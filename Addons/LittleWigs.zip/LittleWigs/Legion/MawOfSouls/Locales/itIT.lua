local L = BigWigs:NewBossLocale("Maw of Souls Trash", "itIT")
if not L then return end
if L then
	L.soulguard = "Guardia dell'Anima Fradicia"
	L.champion = "Campione Helarjar"
	L.mariner = "Marinaio dei Guardiani della Notte"
	L.swiftblade = "Lamalesta Maledetto"
	L.mistmender = "Curatrice delle Nebbie Maledetta"
	L.mistcaller = "Evocanebbie Helarjar"
	L.skjal = "Skjal"
end
