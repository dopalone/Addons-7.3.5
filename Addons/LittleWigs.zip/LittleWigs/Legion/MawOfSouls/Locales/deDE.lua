local L = BigWigs:NewBossLocale("Maw of Souls Trash", "deDE")
if not L then return end
if L then
	L.soulguard = "Aufgedunsene Seelenwache"
	L.champion = "Champion der Helarjar"
	L.mariner = "Matrosennachtwächter"
	L.swiftblade = "Meeresfluchschnellklinge"
	L.mistmender = "Meeresfluchnebelheilerin"
	L.mistcaller = "Nebelruferin der Helarjar"
	L.skjal = "Skjal"
end
