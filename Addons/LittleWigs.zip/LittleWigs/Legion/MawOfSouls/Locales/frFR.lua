local L = BigWigs:NewBossLocale("Maw of Souls Trash", "frFR")
if not L then return end
if L then
	L.soulguard = "Garde des âmes saumâtre"
	L.champion = "Champion helarjar"
	L.mariner = "Marin de la garde de nuit"
	L.swiftblade = "Vivelame maudit par les flots"
	L.mistmender = "Soignebrume maudite par les flots"
	L.mistcaller = "Mandebrume helarjar"
	L.skjal = "Skjal"
end
