local L = BigWigs:NewBossLocale("Maw of Souls Trash", "zhCN")
if not L then return end
if L then
	--L.soulguard = "Waterlogged Soul Guard"
	L.champion = "海拉加尔勇士"
	L.mariner = "守夜水手"
	--L.swiftblade = "Seacursed Swiftblade"
	L.mistmender = "海咒雾疗师"
	L.mistcaller = "海拉加尔召雾者"
	L.skjal = "斯卡加尔"
end
