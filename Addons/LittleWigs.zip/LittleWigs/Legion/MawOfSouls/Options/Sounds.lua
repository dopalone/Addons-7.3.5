
BigWigs:AddSounds("Ymiron", {
	[193211] = "Alert",
	[193364] = "Long",
	[193566] = "Warning",
	[193977] = "Alarm",
})

BigWigs:AddSounds("Harbaron", {
	[194216] = "Alert",
	[194231] = "Info",
	[194325] = "Warning",
	[194668] = "Alarm",
})

BigWigs:AddSounds("Helya", {
	[185539] = "Warning",
	[196947] = "Info",
	[197262] = "Alert",
	[198495] = "Warning",
	[202088] = "Alarm",
	[227233] = "Alarm",
	["destructor_tentacle"] = "Warning",
	["stages"] = "Info",
})

BigWigs:AddSounds("Maw of Souls Trash", {
	[192019] = "Long",
	[194615] = "Alarm",
	[194657] = "Alarm",
	[195293] = "Long",
	[198324] = {"Alarm","Warning"},
	[198405] = {"Info","Warning"},
	[199514] = {"Alarm","Alert"},
	[199589] = {"Alarm","Alert"},
	[216197] = "Alarm",
})
