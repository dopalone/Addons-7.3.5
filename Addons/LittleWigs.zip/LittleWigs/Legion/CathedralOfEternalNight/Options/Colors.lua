
BigWigs:AddColors("Agronox", {
	[235751] = "Urgent",
	[236524] = "Attention",
	[236527] = "Attention",
	[236639] = "Attention",
	[236640] = "Personal",
	[236650] = {"Attention","Personal"},
	[238674] = "Personal",
})

BigWigs:AddColors("Thrashbite the Scornful", {
	[237276] = "Urgent",
	[237726] = {"Personal","Urgent"},
	[243124] = "Important",
})

BigWigs:AddColors("Domatrax", {
	[-15076] = "Important",
	[234107] = "Urgent",
	[236543] = "Attention",
	[238410] = {"Personal","Urgent"},
})

BigWigs:AddColors("Mephistroth", {
	[233155] = "Attention",
	[233196] = {"Attention","Important","Personal"},
	[233206] = {"Attention","Positive"},
	[234817] = "Attention",
})

BigWigs:AddColors("Cathedral of Eternal Night Trash", {
	[236737] = {"Attention","Personal"},
	[237391] = "Urgent",
	[237565] = "Attention",
	[238543] = "Urgent",
	[238653] = "Urgent",
	[239101] = "Urgent",
	[239232] = "Urgent",
	[239320] = "Urgent",
	[241598] = "Attention",
	[241772] = "Urgent",
	[242760] = "Important",
})
