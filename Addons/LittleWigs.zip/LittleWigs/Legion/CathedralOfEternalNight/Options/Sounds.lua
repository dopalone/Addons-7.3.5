
BigWigs:AddSounds("Agronox", {
	[235751] = "Alarm",
	[236524] = "Info",
	[236527] = "Alert",
	[236639] = "Alert",
	[236640] = "Alert",
	[236650] = {"Alert","Warning"},
	[238674] = "Alarm",
})

BigWigs:AddSounds("Thrashbite the Scornful", {
	[237276] = "Alert",
	[237726] = "Warning",
	[243124] = "Alert",
})

BigWigs:AddSounds("Domatrax", {
	[-15076] = "Alarm",
	[234107] = "Warning",
	[236543] = "Alert",
	[238410] = {"Alert","Warning"},
})

BigWigs:AddSounds("Mephistroth", {
	[233155] = "Alarm",
	[233196] = {"Alert","Warning"},
	[233206] = {"Long","Warning"},
	[234817] = "Alarm",
})

BigWigs:AddSounds("Cathedral of Eternal Night Trash", {
	[236737] = "Alert",
	[237391] = "Warning",
	[237565] = "Long",
	[238543] = "Warning",
	[238653] = "Alarm",
	[239101] = "Warning",
	[239232] = "Warning",
	[239320] = "Warning",
	[241598] = "Long",
	[241772] = "Warning",
	[242760] = "Alarm",
})
