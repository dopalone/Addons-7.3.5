
BigWigs:AddColors("Baron Ashbury", {
	[93423] = "Important",
	[93581] = {"Personal","Urgent"},
	[93757] = "Attention",
})

BigWigs:AddColors("Baron Silverlaine", {
	[93857] = {"Attention","Important"},
})

BigWigs:AddColors("Commander Springvale", {
	[93687] = "Personal",
	[93844] = "Urgent",
	[93852] = {"Important","Personal"},
})

BigWigs:AddColors("Lord Walden", {
	[93505] = "Important",
	[93527] = "Attention",
	[93617] = {"Neutral","Personal","Urgent"},
	[93689] = "Neutral",
	[93697] = "Important",
})

BigWigs:AddColors("Lord Godfrey", {
	[93520] = {"Important","Personal"},
	[93629] = {"Personal","Urgent"},
	[93675] = {"Attention","Personal"},
	[93707] = "Neutral",
})
