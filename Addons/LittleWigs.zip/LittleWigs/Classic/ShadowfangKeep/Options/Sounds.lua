
BigWigs:AddSounds("Baron Ashbury", {
	[93757] = "Long",
})

BigWigs:AddSounds("Commander Springvale", {
	[93687] = "Alert",
	[93844] = "Alarm",
})

BigWigs:AddSounds("Lord Walden", {
	[93617] = {"Info","Warning"},
	[93689] = "Info",
})

BigWigs:AddSounds("Lord Godfrey", {
	[93520] = {"Alert","Long"},
	[93629] = "Alarm",
	[93707] = "Info",
})
