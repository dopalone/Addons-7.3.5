
BigWigs:AddColors("Glubtok", {
	["stages"] = "Neutral",
})

BigWigs:AddColors("Helix Gearbreaker", {
	[88352] = {"Important","Personal"},
})

BigWigs:AddColors("Foe Reaper 5000", {
	[88481] = "Urgent",
	[88495] = {"Important","Personal"},
	[88522] = "Attention",
})

BigWigs:AddColors("Vanessa VanCleef", {
	[92614] = "Urgent",
	[95542] = "Attention",
})
