# LittleWigs

## [v7.3.24](https://github.com/BigWigsMods/LittleWigs/tree/v7.3.24) (2018-04-22)
[Full Changelog](https://github.com/BigWigsMods/LittleWigs/compare/v7.3.23...v7.3.24)

- update option files  
- WotLK/TheCullingOfStratholme/MalGanis: Play "Info" on Vampiric Touch cast.  
- WotLK/AzjolNerub/Anubarak: Play "Warning" on Pound cast.  
- update option files  
- TBC/AuchenaiCrypts/Maladaar: Play "Info" on avatar cast.  
- WoD/IronDocks/Nokgar: added CD bars for "Reckless Provocation" and messages for stages (#280)  
- Underrot: Fix some spell ids  
- Add BFA option files  
- Update colors and sounds  
- Add Battle for Azeroth dungeons (#185)  
- MawOfSouls/Trash: don't show a message for "Sea Legs" when mages spellsteal it  
- Karazhan/Curator: Fix Power Discharge warning  
- MawOfSouls/Trash: added warnings for "Soul Siphon", "Sea Legs" and "Give No Quarter", added missing localized NPC names, added throttling for casts' warnings (#274)  
- Karazhan/Vizaduum: added CD bars for spells that were already tracked, added "Bombardment", a proximity display for Stage 3, warnings when taking damage from Soul Harvesters, cleanups (#292)  
- Legion/Karazhan/ShadeOfMedivh: added bars for "Flame Wreath" and "Ceaseless Winter", fixed "Focused Power" bar showing an incorrect value during "Guardian's Image", cleanups  
- Legion/Karazhan/Curator: tweaked Evocation's CD  
- WotLK/TheForgeOfSouls/Bronjahm: Fix soon message/lua error (#291)  
- Legion/Karazhan/Curator: Add Evocation cooldown bars  
