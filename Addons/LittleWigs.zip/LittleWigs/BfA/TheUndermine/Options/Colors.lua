
BigWigs:AddColors("Coin-Operated Crowd Pummeler", {
	[256493] = {"blue","green","Personal"},
	[257337] = "orange",
	[262347] = "yellow",
	[269493] = "cyan",
})

BigWigs:AddColors("Tik'ali", {
	[257582] = {"Personal","red"},
	[257593] = "cyan",
	[257597] = "yellow",
	[258622] = "orange",
})

BigWigs:AddColors("Rixxa Fluxflame", {
	[259022] = "red",
	[259853] = {"orange","Personal"},
	[260669] = "yellow",
})

BigWigs:AddColors("Mogul Razzdunk", {
	[260202] = "orange",
	[260279] = "yellow",
	[260811] = "red",
	[270277] = "yellow",
})
