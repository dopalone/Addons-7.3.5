
BigWigs:AddSounds("Coin-Operated Crowd Pummeler", {
	[256493] = {"alarm","info"},
	[257337] = "alarm",
	[262347] = "alert",
	[269493] = "long",
})

BigWigs:AddSounds("Tik'ali", {
	[257582] = "warning",
	[257593] = "info",
	[257597] = "alert",
	[258622] = "long",
})

BigWigs:AddSounds("Rixxa Fluxflame", {
	[259022] = "long",
	[259853] = "alarm",
	[260669] = "alert",
})

BigWigs:AddSounds("Mogul Razzdunk", {
	[260202] = "alert",
	[260279] = "alert",
	[260811] = "warning",
	[270277] = "long",
})
