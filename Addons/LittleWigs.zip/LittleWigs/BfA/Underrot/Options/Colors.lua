
BigWigs:AddColors("Elder Leaxa", {
	[260879] = "orange",
	[260894] = "yellow",
	[264603] = "red",
})

BigWigs:AddColors("Infested Crawg", {
	[260292] = "yellow",
	[260333] = "orange",
	[260793] = "red",
})

BigWigs:AddColors("Sporecaller Zancha", {
	[259602] = "orange",
	[259718] = {"Personal","yellow"},
	[259732] = "red",
	[259830] = "cyan",
})

BigWigs:AddColors("Taloc the Corrupted", {
	[269301] = "yellow",
	[269310] = "green",
	[269406] = "cyan",
	[269692] = "green",
	[269843] = "red",
})
