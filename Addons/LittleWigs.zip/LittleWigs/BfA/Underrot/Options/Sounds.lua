
BigWigs:AddSounds("Elder Leaxa", {
	[260879] = "alert",
	[260894] = "info",
	[264603] = "long",
})

BigWigs:AddSounds("Infested Crawg", {
	[260292] = "alert",
	[260333] = "long",
	[260793] = "warning",
})

BigWigs:AddSounds("Sporecaller Zancha", {
	[259602] = "alert",
	[259718] = "warning",
	[259732] = "long",
	[259830] = "info",
})

BigWigs:AddSounds("Taloc the Corrupted", {
	[269301] = "alert",
	[269310] = "long",
	[269406] = "info",
	[269843] = "warning",
})
