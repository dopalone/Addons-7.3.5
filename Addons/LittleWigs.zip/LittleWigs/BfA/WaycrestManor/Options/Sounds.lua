
BigWigs:AddSounds("Heartsbane Triad", {
	[260703] = "Alarm",
	[260741] = "Alarm",
	[260773] = "Warning",
	[260907] = "Alarm",
})

BigWigs:AddSounds("Soulbound Goliath", {
	[260512] = "Alert",
	[267907] = "Alarm",
})

BigWigs:AddSounds("Raal the Gluttonous", {
	[264694] = "Alarm",
	[264734] = "Warning",
	[264923] = "Warning",
	[264931] = "Long",
	[265002] = "Alert",
})

BigWigs:AddSounds("Lord and Lady Waycrest", {
	[261417] = "Alarm",
	[261438] = "Alert",
	[261440] = "Warning",
	[261446] = "Long",
})

BigWigs:AddSounds("Gorak Tul", {
	[266181] = "Warning",
	[266198] = "Long",
	[266225] = "Warning",
	[266258] = "Alert",
	[268202] = "Alarm",
	[268208] = "Info",
})
