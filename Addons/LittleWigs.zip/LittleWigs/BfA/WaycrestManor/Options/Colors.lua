
BigWigs:AddColors("Heartsbane Triad", {
	[260703] = {"orange","Personal"},
	[260741] = "orange",
	[260773] = "red",
	[260907] = {"orange","Personal"},
})

BigWigs:AddColors("Soulbound Goliath", {
	[260512] = "yellow",
	[267907] = {"orange","Personal"},
})

BigWigs:AddColors("Raal the Gluttonous", {
	[264694] = "orange",
	[264734] = "orange",
	[264923] = "red",
	[264931] = "yellow",
	[265002] = "orange",
})

BigWigs:AddColors("Lord and Lady Waycrest", {
	[261417] = "orange",
	[261438] = "yellow",
	[261440] = {"Personal","red"},
	[261446] = "cyan",
})

BigWigs:AddColors("Gorak Tul", {
	[266181] = "red",
	[266198] = "green",
	[266225] = "orange",
	[266258] = "yellow",
	[268202] = {"orange","Personal"},
	[268208] = "cyan",
})
