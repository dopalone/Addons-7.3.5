
BigWigs:AddColors("Skycap'n Kragg", {
	[255952] = "yellow",
	[256016] = "blue",
	[256060] = "red",
	[256106] = "yellow",
	["stages"] = "cyan",
})

BigWigs:AddColors("Council o' Captains", {
	[256589] = "orange",
	[258338] = "yellow",
	[258381] = "red",
})

BigWigs:AddColors("Ring of Booty", {
	[256358] = "yellow",
	[256405] = "red",
	[256489] = "cyan",
})

BigWigs:AddColors("Harlan Sweete", {
	[257278] = "yellow",
	[257305] = {"blue","orange"},
	[257314] = {"Personal","yellow"},
	[257316] = "red",
	["stages"] = "cyan",
})
