
BigWigs:AddSounds("Skycap'n Kragg", {
	[255952] = "alert",
	[256016] = "alarm",
	[256060] = "warning",
	[256106] = "alert",
	["stages"] = "info",
})

BigWigs:AddSounds("Council o' Captains", {
	[256589] = "long",
	[258338] = "alert",
	[258381] = "warning",
})

BigWigs:AddSounds("Ring of Booty", {
	[256358] = "alert",
	[256405] = "warning",
	[256489] = "info",
})

BigWigs:AddSounds("Harlan Sweete", {
	[257278] = "alert",
	[257305] = {"alarm","warning"},
	[257314] = "warning",
	[257316] = "long",
	["stages"] = {"Info","info"},
})
