
BigWigs:AddSounds("Adderis and Aspix", {
	[263234] = "Alert",
	[263246] = "Info",
	[263257] = "Long",
	[263371] = "Warning",
	[263424] = "Alert",
	[263758] = "Alarm",
})

BigWigs:AddSounds("Merektha", {
	[263912] = "Alert",
	[263914] = "Warning",
	[263927] = "Alarm",
	[263957] = "Alert",
	[264206] = "Alarm",
	[264233] = "Long",
})

BigWigs:AddSounds("Galvazzt", {
	[266512] = "Warning",
	[266923] = "Info",
})

BigWigs:AddSounds("Avatar of Sethraliss", {
	[266232] = "Info",
	[267931] = "Alarm",
	[267979] = "Alert",
	[268007] = "Alarm",
	[268012] = "Alarm",
	[268013] = "Alert",
	[268020] = "Alert",
	[268024] = "Warning",
	[268061] = "Alert",
})
