
BigWigs:AddColors("Adderis and Aspix", {
	[263234] = "yellow",
	[263246] = {"cyan","Personal"},
	[263257] = "orange",
	[263371] = {"Personal","red"},
	[263424] = "yellow",
	[263758] = "orange",
})

BigWigs:AddColors("Merektha", {
	[263912] = "yellow",
	[263914] = "red",
	[263927] = "blue",
	[263957] = {"Personal","yellow"},
	[264206] = "orange",
	[264233] = "cyan",
})

BigWigs:AddColors("Galvazzt", {
	[266512] = "red",
	[266923] = {"cyan","Personal"},
})

BigWigs:AddColors("Avatar of Sethraliss", {
	[266232] = "cyan",
	[267931] = "blue",
	[267979] = {"Personal","yellow"},
	[268007] = "orange",
	[268012] = "orange",
	[268013] = {"Personal","red"},
	[268020] = "yellow",
	[268024] = "red",
	[268061] = "yellow",
})
