
BigWigs:AddColors("The Sand Queen", {
	[257092] = "yellow",
	[257495] = "orange",
	[257608] = {"Personal","red"},
	[257609] = "yellow",
})

BigWigs:AddColors("Jes Howlis", {
	[257777] = {"Personal","yellow"},
	[257785] = "red",
	[257791] = "orange",
	[257793] = "cyan",
	[257827] = {"cyan","orange"},
})

BigWigs:AddColors("Knight Captain Valyri", {
	[256955] = "red",
	[256970] = "yellow",
	[257028] = {"Personal","yellow"},
})

BigWigs:AddColors("Overseer Korgus", {
	[256038] = {"Personal","red"},
	[256083] = "yellow",
	[256101] = "orange",
	[256198] = "cyan",
	[256199] = "cyan",
	[263345] = "yellow",
})
